#!/bin/bash
wget -qO- "https://www.walletexplorer.com/address/15N1KY5ohztgCXtEe13BbGRk85x2FPgW8E?page=10&format=csv" >> rawdata.data

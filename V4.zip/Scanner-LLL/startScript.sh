#!/bin/bash
./lattice.sh 08d917f0fee48b0d765006fa52d62dd3d704563200f2817046973e3bf6d11f1f 15N1KY5ohztgCXtEe13BbGRk85x2FPgW8E >> result.sql
rm *.txt
rm *.csv
rm *.json

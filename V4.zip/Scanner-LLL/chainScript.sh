#!/bin/bash
sed -i 's/BITCOIN/15N1KY5ohztgCXtEe13BbGRk85x2FPgW8E/g' chain3file.py
